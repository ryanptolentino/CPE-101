nums = [1, 2, 3, 4, 5, 6, 7, 8, 9]


def groups_of_three(sep):
    r = []
    s = 0
    e = 3
    while s < len(sep):
        r.append(sep[s:e])
        s += 3
        e += 3
    return r


print(groups_of_three(nums))
